# kjkj

###Configuration instructions.

1. Extract kjkj archive to the Laravel's vendor folder.

2. Add Fjkdj\Application\Providers\kjkjServiceProvider::class to config/app.php's providers array.
   Add Fjkdj\Application\Providers\kjkjEventServiceProvider::class to config/app.php's providers array (Optional. Add only if event is created.).

3. Add the following line to the project's composer.json psr-4 array:
    
    ```
  "psr-4": {
              "App\\": "app/",
              "Fjkdj\\Application\\" : "vendor/kjkj/application/src/"
          }
    ```
4. Run ``` composer dump-autoload ``` from your project root.
5.  (Optional) 

    Run following command to move the package assets, views, config files to your application folder.

     ```
    php artisan vendor:publish
    ```
6. (Optional but Recommended) 
   
    Test your installation by visiting the following URL in your browser.

    http://your-siteurl/kjkj/test

    If you see "You are ready to start building your package." then you have successfully configured the package boilerplate.

7. That's it. Now, You are ready to develop your package.