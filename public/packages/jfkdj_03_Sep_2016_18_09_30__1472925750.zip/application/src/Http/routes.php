<?php

Route::get('/jfkdj/test', function() {
    return "You are ready to start building your package.";
});
