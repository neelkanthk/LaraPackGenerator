<?php

/**
 * Service Provider for the package.
 */

namespace Kjvjk\Application\Providers;

use Illuminate\Support\ServiceProvider;

class jfkdjServiceProvider extends ServiceProvider {

    
    public function register() {
        $this->app->bind('', function($app) {
            //define your package dependencies here.
        });
    }

    public function boot() {

        //Publishes the configuration file to the application's config directory
        $this->publishes([
            __DIR__ . '/../config/jfkdj.php' => config_path('jfkdj.php'),
        ]);

        //Load the routes.php file of the package present inside the src/Http Folder
        require __DIR__ . '/../Http/routes.php';

        //Loading views"
        $this->loadViewsFrom(__DIR__ . '/../resources/views/jfkdj', 'jfkdj');

        //Publish views and assets
        $this->publishes([
            __DIR__ . '/../resources/views/jfkdj' => base_path('resources/views/vendor/jfkdj'),
            __DIR__ . '/../resources/assets' => base_path('public/vendor/jfkdj'),
        ]);

        //Adding the custom middleware to the application's IoC container
        $this->app['router'];
        //Register package middlewares below.
$this->app["router"]->middleware("kj", "Kjvjk\Application\Http\Middlewares\kj");    }

}
