<?php

namespace Kjvjk\Application\Models;

use Illuminate\Database\Eloquent\Model;

class Kj extends Model
{
    //
}
