<?php

/**
 * Service Provider for the package.
 */

namespace Popop\Application\Providers;

use Illuminate\Support\ServiceProvider;

class popopoServiceProvider extends ServiceProvider {

    
    public function register() {
        $this->app->bind('', function($app) {
            //define your package dependencies here.
        });
    }

    public function boot() {

        //Publishes the configuration file to the application's config directory
        $this->publishes([
            __DIR__ . '/../config/popopo.php' => config_path('popopo.php'),
        ]);

        //Load the routes.php file of the package present inside the src/Http Folder
        require __DIR__ . '/../Http/routes.php';

        //Loading views"
        $this->loadViewsFrom(__DIR__ . '/../resources/views/popopo', 'popopo');

        //Publish views and assets
        $this->publishes([
            __DIR__ . '/../resources/views/popopo' => base_path('resources/views/vendor/popopo'),
            __DIR__ . '/../resources/assets' => base_path('public/vendor/popopo'),
        ]);

        //Adding the custom middleware to the application's IoC container
        $this->app['router'];
        //Register package middlewares below.
$this->app["router"]->middleware("", "Popop\Application\Http\Middlewares\");    }

}
