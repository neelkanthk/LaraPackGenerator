<?php

Route::get('/popopo/test', function() {
    return "You are ready to start building your package.";
});
