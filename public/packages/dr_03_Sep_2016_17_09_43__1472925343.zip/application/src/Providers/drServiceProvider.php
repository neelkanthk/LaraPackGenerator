<?php

/**
 * Service Provider for the package.
 */

namespace Df\Application\Providers;

use Illuminate\Support\ServiceProvider;

class drServiceProvider extends ServiceProvider {

    
    public function register() {
        $this->app->bind('', function($app) {
            //define your package dependencies here.
        });
    }

    public function boot() {

        //Publishes the configuration file to the application's config directory
        $this->publishes([
            __DIR__ . '/../config/dr.php' => config_path('dr.php'),
        ]);

        //Load the routes.php file of the package present inside the src/Http Folder
        require __DIR__ . '/../Http/routes.php';

        //Loading views"
        $this->loadViewsFrom(__DIR__ . '/../resources/views/dr', 'dr');

        //Publish views and assets
        $this->publishes([
            __DIR__ . '/../resources/views/dr' => base_path('resources/views/vendor/dr'),
            __DIR__ . '/../resources/assets' => base_path('public/vendor/dr'),
        ]);

        //Adding the custom middleware to the application's IoC container
        $this->app['router'];
        ##REGISTER_MIDDLEWARES##
    }

}
