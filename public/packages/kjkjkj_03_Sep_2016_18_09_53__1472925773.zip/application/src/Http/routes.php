<?php

Route::get('/kjkjkj/test', function() {
    return "You are ready to start building your package.";
});
