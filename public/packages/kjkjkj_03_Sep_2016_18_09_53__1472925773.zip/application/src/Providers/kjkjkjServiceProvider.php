<?php

/**
 * Service Provider for the package.
 */

namespace Dkfj\Application\Providers;

use Illuminate\Support\ServiceProvider;

class kjkjkjServiceProvider extends ServiceProvider {

    
    public function register() {
        $this->app->bind('', function($app) {
            //define your package dependencies here.
        });
    }

    public function boot() {

        //Publishes the configuration file to the application's config directory
        $this->publishes([
            __DIR__ . '/../config/kjkjkj.php' => config_path('kjkjkj.php'),
        ]);

        //Load the routes.php file of the package present inside the src/Http Folder
        require __DIR__ . '/../Http/routes.php';

        //Loading views"
        $this->loadViewsFrom(__DIR__ . '/../resources/views/kjkjkj', 'kjkjkj');

        //Publish views and assets
        $this->publishes([
            __DIR__ . '/../resources/views/kjkjkj' => base_path('resources/views/vendor/kjkjkj'),
            __DIR__ . '/../resources/assets' => base_path('public/vendor/kjkjkj'),
        ]);

        //Adding the custom middleware to the application's IoC container
        $this->app['router'];
        //Register package middlewares below.
$this->app["router"]->middleware("", "Dkfj\Application\Http\Middlewares\");    }

}
