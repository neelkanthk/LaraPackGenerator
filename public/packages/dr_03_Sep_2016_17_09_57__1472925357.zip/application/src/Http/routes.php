<?php

Route::get('/dr/test', function() {
    return "You are ready to start building your package.";
});
