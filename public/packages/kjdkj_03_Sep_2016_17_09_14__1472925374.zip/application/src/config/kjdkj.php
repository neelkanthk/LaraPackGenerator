<?php

/**
 * Configuration file for package.
 * 
 */
return [];