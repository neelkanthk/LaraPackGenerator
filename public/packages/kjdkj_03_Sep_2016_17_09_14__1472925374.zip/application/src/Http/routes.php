<?php

Route::get('/kjdkj/test', function() {
    return "You are ready to start building your package.";
});
