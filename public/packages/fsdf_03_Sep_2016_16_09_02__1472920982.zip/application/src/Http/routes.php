<?php

Route::get('/fsdf/test', function() {
    return "You are ready to start building your package.";
});
